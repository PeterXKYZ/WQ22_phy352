// Peter Zhou
#include <stdlib.h>

void swapD(int*, int*);

void swapT(float*, float*);

void qsortTD(float*, float*, int*, int*);